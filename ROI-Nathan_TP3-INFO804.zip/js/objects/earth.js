import * as THREE from '../../three.module.js';

export function createEarth() {
    const earthGroup = new THREE.Group();

    const textureLoader = new THREE.TextureLoader();
    const map = textureLoader.load( 'images/earth_atmos_2048.jpg' );
    const specularMap = textureLoader.load( 'images/earth_specular_2048.jpg' );
    const normalMap = textureLoader.load( 'images/earth_normal_2048.jpg' );

    const earthGeometry = new THREE.SphereGeometry( 1, 32, 32 );
    const earthMaterial = new THREE.MeshPhongMaterial( {
        map,
        specularMap,
        normalMap,
        specular: new THREE.Color( 0x888888 ),
        shininess: 25,
        normalScale: new THREE.Vector2( 0.7, 0.7 )
    } );
    const earth = new THREE.Mesh( earthGeometry, earthMaterial );

    earth.position.x = 5;
    earth.rotation.x = Math.PI / 5;

    const light = new THREE.PointLight( 0xFAE89F, 10.0 );
    light.position.set( 0, 0, 0 );

    earthGroup.add(light);
    earthGroup.add( earth );

    return { earthGroup, earth };
}
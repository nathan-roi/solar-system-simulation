import * as THREE from '../../three.module.js';

export function createSun() {
    const sunGroup = new THREE.Group();

    const mapUrl = 'images/2k_sun.jpg';
    const map = new THREE.TextureLoader().load( mapUrl );

    const sunGeometry = new THREE.SphereGeometry( 2, 32, 32 );
    const sunMaterial = new THREE.MeshBasicMaterial( {
        color: 0xFAE89F,
        map
    } );
    const sun = new THREE.Mesh( sunGeometry, sunMaterial );

    const light = new THREE.PointLight( 0xffffff, 10.0 );
    light.position.set( 0, 0, 0 );

    sunGroup.add( sun );
    sunGroup.add( light );

    return { sunGroup, sun, light };
}

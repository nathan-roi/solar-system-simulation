import * as THREE from '../three.module.js';
import { OrbitControls} from 'three/addons/controls/OrbitControls.js';
import { startRenderLoop } from './animation-loop.js';
import { createScene } from './scene-setup.js';
import { isWebGLSupported } from './webgl-support.js';

const canvas = document.getElementById( 'webglcanvas' );

if ( !canvas ) {
  throw new Error( 'Canvas #webglcanvas introuvable.' );
}

if ( !isWebGLSupported( canvas ) ) {
  console.log( 'WebGL not supported on your browser.' );
} else {
  const renderer = new THREE.WebGLRenderer( {
    canvas,
    antialias: true
  } );

  renderer.setSize( window.innerWidth, window.innerHeight );

  const { scene, camera, sunGroup, sun, earthGroup, earth } = createScene();

  window.addEventListener( 'resize', () => {
    renderer.setSize( window.innerWidth, window.innerHeight );
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
  } );

  controls = new OrbitControls( camera, renderer.domElement );
  // controls.addEventListener( 'change', render ); // call this only in static scenes (i.e., if there is no animation loop)
  controls.enableDamping      = true; // an animation loop is required when either damping or auto-rotation are enabled
  controls.dampingFactor      = 0.25;
  controls.screenSpacePanning = false;
  controls.minDistance        = 1;
  controls.maxDistance        = 10;
  controls.maxPolarAngle      = Math.PI / 2;

  startRenderLoop( { renderer, scene, camera, sunGroup, sun, earthGroup, earth, controls } );


}

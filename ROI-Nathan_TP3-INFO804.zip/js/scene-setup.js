import * as THREE from '../three.module.js';
import { createEarth } from './objects/earth.js';
import { createSun } from './objects/sun.js';

export function createScene() {
  const scene = new THREE.Scene();

  const camera = new THREE.PerspectiveCamera(
    100,
    window.innerWidth / window.innerHeight,
    2,
    4500
  );

  const { sunGroup, sun } = createSun();
  const { earthGroup, earth } = createEarth();
  sunGroup.add( earthGroup );
  sunGroup.position.z = -8;

  camera.position.set( 0, 3, 0 );
  camera.lookAt( 0, 0, -8 );

  sun.rotation.x = Math.PI / 5;
  sun.rotation.y = Math.PI / 5;

  scene.add( sunGroup );

  return { scene, camera, sunGroup, sun, earthGroup, earth };
}

export function startRenderLoop( { renderer, scene, camera, sunGroup, sun, earthGroup, earth, controls } ) {
  const twoPi = Math.PI * 2;
  const startTime = performance.now();
  const YEAR_DURATION_SECONDS = 200;

  const earthYearDurationSeconds = YEAR_DURATION_SECONDS;
  const earthDayDurationSeconds = earthYearDurationSeconds / 365;
  const sunRotationDurationSeconds = earthDayDurationSeconds * 25;

  function animate() {
    controls.update();

    const elapsedSeconds = ( performance.now() - startTime ) / 1000;

    const earthOrbitAngle = ( elapsedSeconds % earthYearDurationSeconds )
      / earthYearDurationSeconds * twoPi;
    const earthRotationAngle = ( elapsedSeconds % earthDayDurationSeconds )
      / earthDayDurationSeconds * twoPi;
    const sunRotationAngle = ( elapsedSeconds % sunRotationDurationSeconds )
      / sunRotationDurationSeconds * twoPi;

    earthGroup.rotation.y = earthOrbitAngle;
    earth.rotation.y = earthRotationAngle;
    sun.rotation.y = sunRotationAngle;
  }

  function render() {
    renderer.render( scene, camera );
  }

  function run() {
    requestAnimationFrame( run );
    render();
    animate();
  }

  run();
}

export function isWebGLSupported( canvas ) {
  return !!( window.WebGLRenderingContext
    && ( canvas.getContext( 'webgl' )
      || canvas.getContext( 'experimental-webgl' ) ) );
}
